export default {
    "development": {
        "id": "master-server-1", "host": "127.0.0.1", "port": 5100
    },
    "production": {
        "id": "master-server-1", "host": "127.0.0.1", "port": 5100
    }
}