

console.log(new Date().toLocaleString())