
declare global {
    interface Rpc {
        match: {
            main: Remote
        }
    }
}

export default class Remote {

    offline(roomId: number, uid: number) {

    }
}