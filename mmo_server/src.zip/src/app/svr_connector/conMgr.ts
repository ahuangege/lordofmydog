import { Session } from "mydog";
import { Dic } from "../util/util";



export class ConMgr {

    accDic: Dic<Session> = {};




}


